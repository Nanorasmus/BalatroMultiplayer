SMODS.Atlas({
	key = "sticker_nemesis",
	path = "sticker_nemesis.png",
	px = 71,
	py = 95,
})

SMODS.Sticker({
	key = "sticker_nemesis",
	atlas = "sticker_nemesis",
	badge_colour = G.C.MULITPLAYER,
	default_compat = false,
	needs_enable_flag = true,
	hide_badge = true,
})
