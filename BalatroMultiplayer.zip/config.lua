return {
	["username"] = "Guest",
	["server_url"] = "balatro.virtualized.dev",
	["server_port"] = 6858,
	["logging"] = false,
	["misprint_display"] = true,
}
