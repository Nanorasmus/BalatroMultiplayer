MP.Ruleset({
	key = "weekly",
	challenge_deck = "c_mp_weekly"
})
